from .rust_scorer import *

__doc__ = rust_scorer.__doc__
if hasattr(rust_scorer, "__all__"):
    __all__ = rust_scorer.__all__